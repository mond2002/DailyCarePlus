package com.example.listview_season2_ex

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class ListviewAdapter(val list:MutableList<String> ):BaseAdapter() {
    override fun getCount(): Int {
     return list.size
    }


    override fun getItem(position: Int): Any {
        return list[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        var covertView = convertView
        if(convertView == null){

            covertView= LayoutInflater.from(parent?.context).inflate(R.layout.listview_item,parent,false)


        }
        val title = covertView!!.findViewById<TextView>(R.id.listviewItemText)
        title.text = list[position]

        return covertView!!



    }
}