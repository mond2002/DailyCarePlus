package com.example.listview_season2_ex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list_item = mutableListOf<String>()
        list_item.add("A")
        list_item.add("B")
        list_item.add("C")

        val listview = findViewById<ListView>(R.id.mainListView)
        val listviewAdapter = ListviewAdapter(list_item)

       listview.adapter = listviewAdapter  //갑자기 리스트 뷰 어뎁터를 설정했는데 어디서 튀어나온것인가?

        listview.setOnItemClickListener {parent,view,position,id ->

          Toast.makeText(this, list_item[position], Toast.LENGTH_LONG).show()
        }


    }
}